'use client'

import React from "react";
import styled from "styled-components";

import HeaderImagesV0 from "@/components/ui/HeaderImagesV0";
import { CloseButton, Dialog, Portal } from "@chakra-ui/react";
import Link from "next/link";
import { RadialFollowLink} from "./RadialFollowLink";

function HomePageComp() {

  const [modalIsOpen, setModalIsOpen] = React.useState(false);

  // “On-demand branding & web design powered by AI, directed by humans.”


  return (
    <>
    {/* <h1>Bodilum helps businesses and agencies design, build and launch premium digital experiences, AI workflows and conversion-focused systems.</h1> */}
    <HeaderImagesV0 />
    <HomePageWrapper>

      <h1>
        <span className="emp1">Motion-led Design, Web Experiences & Growth Systems</span> <b>for ambitious businesses and creative teams.</b>
     </h1>
     <p>From brand direction and cinematic web experiences to AI-powered workflows and monthly studio support, Bodilum helps ambitious businesses build sharper digital presence, stronger storytelling, and systems that convert.</p>
     {/* <p>Bodilum helps ambitious small businesses and creative teams create sharper brands, better websites, premium web experiences and practical AI-powered workflows — without hiring a full in-house team.</p> */}
     
     
     <div className="home-page-ctas">

        {/* <Link href="/design-direction" className="primary-cta">Choose Design Direction</Link> */}
        {/* <Link href="/growth-systems">View Monthly Growth System Packages</Link> */}

        <RadialFollowLink href="/growth-systems" tone="dark">
          View Monthly Plans
        </RadialFollowLink>

        <RadialFollowLink
          href="mailto:hello@bodilum.com?subject=Project%20Enquiry%20for%20Bodilum"
          tone="outline"
          prefetch={false}
        >
          Start a Project
        </RadialFollowLink>

      </div>

     {/* <h1>
        Turn your <b>boldest</b> <span className="emp1">design ideas</span> into reality <b>in hours</b> —not weeks.
     </h1> */}

     {/* <div className="lara-chat-bot">
        <div id="lara-user-input" contentEditable="true" role="textbox" aria-multiline="true" aria-label="Editable description area" aria-placeholder="Describe your design idea..." className="relative min-h-[120px] w-full rounded-md border border-gray-300 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 empty:before:content-[attr(aria-placeholder)] empty:before:text-gray-400 empty:before:absolute empty:before:left-3 empty:before:top-3 empty:before:cursor-text" onClick={ () => setModalIsOpen(true) }>
        </div>
        <span>Lara, our design AI-powered project manager, uses AI to help you refine your design brief using AI powered pre-made designs, uploaded references, and your initial design brief. It then manages the communication with our world-class design talents to execute your ideas in hours, not weeks!</span>
     </div> */}

    </HomePageWrapper>
    {modalIsOpen && (
      <Dialog.Root
        key="modal-form"
        size="lg"
        open={modalIsOpen}
        onOpenChange={(open) => setModalIsOpen(open.open)}
      >
        <Portal>
          <Dialog.Backdrop />
          <Dialog.Positioner>
            <Dialog.Content>
              <Dialog.Header>
                <Dialog.Title>
                  <p className="text-2xl font-bold">This feature is launching soon 🚀</p>
                </Dialog.Title>
              </Dialog.Header>
              <Dialog.Body>
                <p className="text-lg">We are working hard to launch this feature in the next few weeks. Stay tuned!</p>
                <h2 className="text-3xl! font-bold! mt-4!">In the meantime, explore our services:</h2>
                <div className="ctas" style={{ display: 'flex', gap: '1rem', alignItems: 'center', justifyContent: 'center', textAlign: 'center', lineHeight: 1.0 }}>
                  <Link href="/services/design" className="inline-block rounded-full border border-[#ccc] mt-2! bg-[#222] px-4! py-2! font-extrabold! text-[#ccc]! transition hover:border-[#222] hover:bg-[#000] hover:text-[#f7f7f7]!">See our design services</Link>
                  <Link href="/services/web-development" className="inline-block rounded-full border border-[#ccc] mt-2! bg-[#222] px-4! py-2! font-extrabold! text-[#ccc]! transition hover:border-[#222] hover:bg-[#000] hover:text-[#f7f7f7]!">See our Web development services</Link>
                  <Link href="/services/ai-integrations" className="inline-block rounded-full border border-[#ccc] mt-2! bg-[#222] px-4! py-2! font-extrabold! text-[#ccc]! transition hover:border-[#222] hover:bg-[#000] hover:text-[#f7f7f7]!">See our AI Integration services</Link>
                </div>
              </Dialog.Body>
              <Dialog.Footer>
              </Dialog.Footer>
              <Dialog.CloseTrigger asChild>
                <CloseButton size="sm" />
              </Dialog.CloseTrigger>
            </Dialog.Content>
          </Dialog.Positioner>
        </Portal>
      </Dialog.Root>
    )}
    </>
  )
}

export default HomePageComp;

const HomePageWrapper = styled.div`
  width: min(1200px, 90%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3rem;
  margin-bottom: 10rem;

    h1 {
      margin-top: 5rem;
      text-align: center;
      font-size: clamp(2.0rem, 5vw, 3.5rem);
      line-height: 1.5;
    }

    h1 .emp1 {
        display: block;
        text-transform: capitalize;
        font-weight: bolder;
        font-size: clamp(3.5rem, 15vw, 9rem);
        letter-spacing: -1px;
        line-height: 1.2;
    }
    h2{
        display: block;
        text-transform: capitalize;
        font-weight: bolder;
        font-size: clamp(1.5rem, 4vw, 2rem);
        letter-spacing: -1px;
        line-height: 0.8;
    }
    h3{
        display: block;
        text-transform: capitalize;
        font-weight: bolder;
        font-size: clamp(1rem, 3vw, 1.5rem);
        letter-spacing: 1px;
        line-height: 0.8;
    }

    p {
        width: min(720px, 90%);
        font-size: clamp(12px, 2.5vw, 20px);
        line-height: 1.2;
        text-align: center;
        color: #555;
    }

    @media all and (min-width: 768px) {
        h1 {
          margin-top: 15rem;
        }
    }

    .home-page-ctas {
      width: min(650px, 90%);
      display: flex;
      gap: 1rem;
      align-items: center;
      justify-content: center;
      text-align: center;
      line-height: 1.0;

      flex-direction: column;

      // a, button {
      //   display: block;
      //   padding: 1rem 2rem;
      //   border-radius: 40px;
      //   border: 2px solid #222;
      //   background: #fff;
      //   color: #222;
      //   font-weight: bold;
      //   transition: all 0.3s ease-in-out;

      //   &:hover {
      //     background: #f7f7f7;
      //     color: #000;
      //   }
      // }
      
      // .primary-cta {
      //   padding: 1rem 2rem;
      //   background: #222;
      //   color: #fff;

      //   &:hover {
      //     background: #000;
      //     color: #f7f7f7;
      //   }
      // }
    }

    .small-info {
      font-size: clamp(12px, 2vw, 16px);
      margin-top: -1rem;
      margin-bottom: 2rem;
      color: #999;
    }


    @media all and (min-width: 768px) {
      .home-page-ctas {
        flex-direction: row;

        // a, button {

        //   &:hover {
        //   }
        // }
        
        // .primary-cta {

        //   &:hover {
        //   }
        // }
      }
    }

    @media all and (min-width: 1024px) {
        h1 {
            margin-top: clamp(5rem, calc(15vw + 2rem), 15rem);            
            line-height: 1.4;
        }
        h1 .emp1 {
            letter-spacing: -10px;
            line-height: 0.9;
        }
    }

  .lara-chat-bot {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1rem;

    #lara-user-input {      
      width: min(650px, 90%);
      height: auto;
      min-height: 100px;
      max-height: 400px;
      padding: 25px;
      border-radius: 20px;
      font-size: 1rem;
      border: 0.5px solid #f0f0f0;
      resize: vertical;
      background: #fff;

      color: #777;

        -webkit-box-shadow: 10px 50px 30px 2px rgba(0,0,0,0.1);
        -moz-box-shadow:    10px 50px 30px 2px rgba(0,0,0,0.1);
        box-shadow:         10px 50px 30px 2px rgba(0,0,0,0.1); 

        -webkit-transition: all 0.2s ease-in-out;
        -moz-transition: all 0.2s ease-in-out;
        -o-transition: all 0.2s ease-in-out;
        transition: all 0.2s ease-in-out;
    }
    span {
        text-align: center;
        line-height: 0.8;
        color: #ccc;
        width: min(500px, 90%);
        font-size: clamp(8px, 1.5vw, 10px);
      }
   }
`;