'use client'

import styled from 'styled-components';
import ImageCardV0 from './ImageCardV0';

function HeaderImagesV0() {
  return (
    <HeaderImagesV0Wrapper>
        <div className="featured-works">
            <ImageCardV0 offsetX={-30} offsetY={4} rotation={15} imageUrl='web-landing-4.webp' />
            <ImageCardV0 offsetX={-20} offsetY={5} rotation={15} imageUrl='mobile-ui-2.webp' />
            <ImageCardV0 offsetX={-10} rotation={-5} imageUrl='comp-design-8.webp' />
            <ImageCardV0 offsetX={5} rotation={-10} imageUrl='comp-design-5.webp' />
            <ImageCardV0 offsetX={15} rotation={-15} imageUrl='comp-design-7.webp' />
        </div>
    </HeaderImagesV0Wrapper>
  )
}

export default HeaderImagesV0;

const HeaderImagesV0Wrapper = styled.div`
width: 100%;
height: 70vh;   
display: flex;
overflow: hidden;
flex-direction: column;
align-items: center;
justify-content: center;
z-index: 1;
position: absolute;
top: 0; left: 0;

.featured-works {
    width: max-content;
    height: max-content;
    display: flex;
    justify-content: center;
    position: relative;
    transform: translateY(-72vh);
    border: 50px solid skyblue;
  }

  @media all and (min-width: 768px) {
    .featured-works {
      transform: translateY(-60vh);
      border: 5px solid pink;
    }
  }
`;